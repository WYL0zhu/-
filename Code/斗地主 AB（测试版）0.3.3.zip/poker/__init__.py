from game import *

while True:
    if input("如果您需要继续游戏，直接回车，否则随便输入一些字符后回车。") != "":
        break
    
    main_start()

    while True:
        if main_loop():
            break
