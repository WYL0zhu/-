POKER = {
    "The Joker (RED)" : 1,
    "The Joker (BLACK)" : 2,
    "Ace of Spades" : 3,
    "Ace of Clubs" : 4,
    "Ace of Hearts" : 5,
    "Ace of Diamonds" : 6,
    "King of Spades" : 7,
    "King of Clubs" : 8,
    "King of Hearts" : 9,
    "King of Diamonds" : 10,
    "Queen of Spades" : 11,
    "Queen of Clubs" : 12,
    "Queen of Hearts" : 13,
    "Queen of Diamonds" : 14,
    "Jack of Spades" : 15,
    "Jack of Clubs" : 16,
    "Jack of Hearts" : 17,
    "Jack of Diamonds" : 18,
    "10 of Spades" : 19,
    "10 of Clubs" : 20,
    "10 of Hearts" : 21,
    "10 of Diamonds" : 22,
    "9 of Spades" : 23,
    "9 of Clubs" : 24,
    "9 of Hearts" : 25,
    "9 of Diamonds" : 26,
    "8 of Spades" : 27,
    "8 of Clubs" : 28,
    "8 of Hearts" : 29,
    "8 of Diamonds" : 30,
    "7 of Spades" : 31,
    "7 of Clubs" : 32,
    "7 of Hearts" : 33,
    "7 of Diamonds" : 34,
    "6 of Spades" : 35,
    "6 of Clubs" : 36,
    "6 of Hearts" : 37,
    "6 of Diamonds" : 38,
    "5 of Spades" : 39,
    "5 of Clubs" : 40,
    "5 of Hearts" : 41,
    "5 of Diamonds" : 42,
    "4 of Spades" : 43,
    "4 of Clubs" : 44,
    "4 of Hearts" : 45,
    "4 of Diamonds" : 46,
    "3 of Spades" : 47,
    "3 of Clubs" : 48,
    "3 of Hearts" : 49,
    "3 of Diamonds" : 50,
    "2 of Spades" : 51,
    "2 of Clubs" : 52,
    "2 of Hearts" : 53,
    "2 of Diamonds" : 54
}
POKERR = list(POKER)

PSIZE = [None, 14, 13, 12, 12, 12, 12, 11, 11, 11, 11, 10, 10, 10, 10, 9, 9, 9,
    9, 8, 8, 8, 8, 7, 7, 7, 7, 6, 6, 6, 6, 5, 5, 5, 5, 4, 4, 4, 4, 3, 3, 3, 3,
    2, 2, 2, 2, 1, 1, 1, 1, 0, 0, 0, 0]

PNAME = [" 2", " 3", " 4", " 5", " 6", " 7", " 8", " 9", " 10", " J", " Q", " K", " A",
" 小王", " 大王"]

PFM = [
    None,
    [{
        "lians" : "1",
        "fens" : 0,
        "mn" : 0,
        "mx" : 14
    }, {
        "lians" : 5,
        "fens" : 0,
        "mn" : 0,
        "mx" : 11
    }],
    [{
        "lians" : "1",
        "fens" : 0,
        "mn" : 0,
        "mx" : 12
    }, {
        "lians" : 3,
        "fens" : 0,
        "mn" : 0,
        "mx" : 11
    }],
    [{
        "lians" : "1",
        "fens" : 1,
        "mn" : 0,
        "mx" : 12
    }, {
        "lians" : 2,
        "fens" : 0,
        "mn" : 0,
        "mx" : 11
    }, {
        "lians" : 2,
        "fens" : "lians",
        "mn" : 0,
        "mx" : 11
    }],
    [{
        "lians" : "1",
        "fens" : "2",
        "mn" : 0,
        "mx" : 12
    }
    ]
]
PBM = [
    None,
    [{
        "lians" : "2",
        "fens" : 0,
        "mn" : 13,
        "mx" : 14
    }],
    None,
    None,
    [{
        "lians" : "1",
        "fens" : 0,
        "mn" : 0,
        "mx" : 12
    }]
]
