import random
import time
from pokers import *

pokers = [Poker(i) for i in POKER]
ran_pokers = [Poker(i) for i in POKER]
first_p = 2
score = [1000, 1000, 1000]

def tpok(a):
    b = [0 for i in range(16)]
    f = [0 for i in range(16)]
    c = 0
    for i in a:
        b[i] += 1
    ans = -1
    for i, j in enumerate(b):
        if j == 0:
            continue
        f[i] = 1
        if j == b[i - 1]:
            f[i] = f[i - 1] + 1
        if f[ans] < f[i] and b[ans] == b[i] or b[ans] < b[i]:
            ans = i
    fen = 0
    fens = 0
    for i in range(ans - f[ans] + 1):
        if b[i] == 0:
            continue
        if fen == 0:
            fen = b[i]
        elif b[i] != fen:
            if b[i] == 1:
                fens *= fen
            else:
                fens += b[i]
                fens -= 1
        fens += 1
    for i in range(ans + 1, 15):
        if b[i] == 0:
            continue
        if fen == 0:
            fen = b[i]
        elif b[i] != fen:
            if b[i] == 1:
                fens *= fen
                fen = 1
            else:
                fens += b[i]
                fens -= 1
        fens += 1
    try:
        return PokFunc(b[ans], f[ans], fen, fens, ans - f[ans] + 1)
    except IndexError:
        return PokFunc(b[ans], f[ans], 1, fen * fens, ans - f[ans] + 1)

def chai(a):
    b = [0 for i in range(15)]
    for i in a:
        b[i] += 1
    k = 0
    l = 0
    shunz = []
    for i in range(12):
        if b[i] == 0:
            l = 0
        else:
            l += 1
            k += min(2, b[i] - 1)
            if l == 5:
                if k <= 2:
                    for j in range(i - 4, i + 1):
                        b[j] -= 1
                    shunz.append([i - 4, i + 1, 0])
                    k = l = 0
                else:
                    k -= min(2, b[i - 4] - 1)
                    l -= 1
    for j, i in enumerate(shunz):
        if j == 0:
            continue
        if shunz[j - 1][1] == i[0]:
            shunz[j - 1][1] = i[1]
            del shunz[j]
    for i in shunz:
        i[0] -= 1
        while i[0] != -1 and b[i[0]] == 1:
            b[i[0]] = 0
            i[0] -= 1
        i[0] += 1
        while i[1] != 12 and b[i[1]] == 1:
            b[i[1]] = 0
            i[1] += 1
        d = 0
        for k in range(i[0], i[1] - 5):
            if b[k] == 0:
                break
            d += 1
            b[k] += 1
        i[0] += d
        d = 0
        for k in range(i[1] - 1, i[0] + 4, -1):
            if b[k] == 0:
                break
            d += 1
            b[k] += 1
        i[1] -= d
    for i in shunz:
        for j in range(i[0] + 4, i[1] - 4):
            if b[j] == 1:
                l = j - 1
                while l != -1 and b[l] == 1:
                    l -= 1
                l += 1
                r = j + 1
                while r != 12 and b[r] == 1:
                    r += 1
                k = [l, i[1], 0]
                i[1] = r
                shunz.append(k)
                break
    l = 0
    liand = []
    for i in range(12):
        if b[i] != 2:
            l = 0
        else:
            l += 1
            if l == 3:
                for j in range(i - 2, i + 1):
                    b[j] -= 2
                liand.append([i - 2, i + 1, 0])
                l = 0
    for j, i in enumerate(liand):
        if j == 0:
            continue
        if liand[j - 1][1] == i[0]:
            liand[j - 1][1] = i[1]
            del liand[j]
    for i in liand:
        i[0] -= 1
        while i[0] != -1 and b[i[0]] == 2:
            b[i[0]] = 0
            i[0] -= 1
        i[0] += 1
        while i[1] != 12 and b[i[1]] == 2:
            b[i[1]] = 0
            i[1] += 1
    ds = [0, 0]
    for i in range(13):
        if b[i] == 1 or b[i] == 2:
            ds[b[i] - 1] += 1
    l = 0
    feij = []
    for i in range(12):
        if b[i] != 3:
            l = 0
        else:
            l += 1
            if l == 2:
                for j in range(i - 1, i + 1):
                    b[j] -= 3
                feij.append([i - 1, i + 1, 0])
                l = 0
    for j, i in enumerate(feij):
        if j == 0:
            continue
        if feij[j - 1][1] == i[0]:
            feij[j - 1][1] = i[1]
            del feij[j]
    for i in feij:
        i[0] -= 1
        while i[0] != -1 and b[i[0]] == 3:
            b[i[0]] = 0
            i[0] -= 1
        i[0] += 1
        while i[1] != 12 and b[i[1]] == 3:
            b[i[1]] = 0
            i[1] += 1
    pi = []
    dss = [[], []]
    for i in shunz:
        pi.append(PokFunc(1, i[1] - i[0], 0, 0, i[0]))
    for i in liand:
        pi.append(PokFunc(2, i[1] - i[0], 0, 0, i[0]))
    for i in feij:
        for k, j in enumerate(b):
            if (j == 1 or j == 2) and ds[j - 1] >= i[1] - i[0]:
                n = 0
                for l in range(k, 15):
                    m = b[l]
                    if m == j:
                        b[l] = 0
                        dss[j - 1].append(l)
                        n += 1
                    if n == i[1] - i[0]:
                        break
                ds[j - 1] -= i[1] - i[0]
                pi.append(PokFunc(3, i[1] - i[0], j, i[1] - i[0], i[0]))
                break
        else:
            pi.append(PokFunc(3, i[1] - i[0], 0, 0, i[0]))
    for i in range(13):
        if b[i] == 3:
            b[i] = 0
            for k, j in enumerate(b):
                if j == 1 or j == 2:
                    b[k] = 0
                    dss[j - 1].append(k)
                    ds[j - 1] -= 1
                    pi.append(PokFunc(3, 1, j, 1, i))
                    break
            else:
                pi.append(PokFunc(3, 1, 0, 0, i))
    for i in range(13):
        if b[i] == 4:
            for k, j in enumerate(b):
                if (j == 1 or j == 2) and ds[j - 1] >= 2:
                    n = 0
                    for l in range(k, 15):
                        m = b[l]
                        if m == j:
                            b[l] = 0
                            dss[j - 1].append(l)
                            n += 1
                        if n == 2:
                            break
                    ds[j - 1] -= 2
                    pi.append(PokFunc(4, 1, j, 2, i))
                    break
            else:
                pi.append(PokFunc(4, 1, 0, 0, i))
    for i in range(13):
        if b[i] == 1:
            pi.append(PokFunc(1, 1, 0, 0, i))
        elif b[i] == 2:
            pi.append(PokFunc(2, 1, 0, 0, i))
    if b[13] == 1:
        if b[14] == 1:
            pi.append(PokFunc(1, 2, 0, 0, 13))
        else:
            pi.append(PokFunc(1, 1, 0, 0, 13))
    else:
        if b[14] == 1:
            pi.append(PokFunc(1, 1, 0, 0, 14))
    b[13] = b[14] = 0
    return [pi, dss[0], dss[1]]

def main_start():
    global cnt
    global pc
    global d
    global cf
    global last
    global bei
    global chun
    global jipai
    jipai = [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 1, 1]
    cnt = 0
    chun = 1
    while True:
        bei = 1
        random.shuffle(ran_pokers)
        pc = [[], [], []]
        cf = [None, None]
        d = -1
        for i in range(51):
            pc[(i + first_p) % 3].append(ran_pokers[i])
        pc[0].sort()
        pc[1].sort()
        pc[2].sort()
        print("游戏开始了。您的牌是")
        for i in pc[2]:
            print(i)
            time.sleep(0.2)
        sc1 = sc2 = -5
        for i in pc[0]:
            sc1 += max(0, i.size() - 10)
        for i in pc[1]:
            sc2 += max(0, i.size() - 10)
        sc1 = max(0, min(3, sc1))
        sc2 = max(0, min(3, sc2))
        if first_p == 2:
            while True:
                try:
                    sp = int(input("您要叫（分数）："))
                    if sp < 0 or sp > 3:
                        raise ValueError
                    break
                except ValueError:
                    print("请输入 {x ∈ N+ | x ≤ 3} 范围内的数字。")
                except KeyboardInterrupt:
                    print("按错键了，请重叫。")
            if sp != 0:
                d = 2
            if sp == 3:
                pc[2].append(ran_pokers[51])
                pc[2].append(ran_pokers[52])
                pc[2].append(ran_pokers[53])
                pc[2].sort()
                print("您成为了地主。")
                time.sleep(2)
            else:
                time.sleep(0.2)
                if sc1 == 0 or sc1 <= sp:
                    print("电脑 1 不叫。")
                else:
                    print("电脑 1 叫了", sc1, "分。")
                    d = 0
                if sc1 == 3:
                    print("电脑 1 成为了地主。")
                    pc[0].append(ran_pokers[51])
                    pc[0].append(ran_pokers[52])
                    pc[0].append(ran_pokers[53])
                    pc[0].sort()
                    time.sleep(2)
                else:
                    time.sleep(0.2)
                    if sc2 == 0 or sc2 <= max(sp, sc1):
                        print("电脑 2 不叫。")
                    else:
                        print("电脑 2 叫了", sc2, "分。")
                        d = 1
                    if sc2 == 3:
                        print("电脑 2 成为了地主。")
                        pc[1].append(ran_pokers[51])
                        pc[1].append(ran_pokers[52])
                        pc[1].append(ran_pokers[53])
                        pc[1].sort()
                        time.sleep(2)
                    else:
                        time.sleep(0.2)
                        if d == -1:
                            print("无人叫地主，重发牌。")
                            continue
                        elif d == 0:
                            print("电脑 1 成为了地主。")
                            pc[0].append(ran_pokers[51])
                            pc[0].append(ran_pokers[52])
                            pc[0].append(ran_pokers[53])
                            pc[0].sort()
                        elif d == 1:
                            print("电脑 2 成为了地主。")
                            pc[1].append(ran_pokers[51])
                            pc[1].append(ran_pokers[52])
                            pc[1].append(ran_pokers[53])
                            pc[1].sort()
                        else:
                            print("您成为了地主。")
                            pc[2].append(ran_pokers[51])
                            pc[2].append(ran_pokers[52])
                            pc[2].append(ran_pokers[53])
                            pc[2].sort()
                        time.sleep(2)
            break
        elif first_p == 0:
            if sc1 == 0:
                print("电脑 1 不叫。")
            else:
                print("电脑 1 叫了", sc1, "分。")
                d = 0
            if sc1 == 3:
                print("电脑 1 成为了地主。")
                pc[0].append(ran_pokers[51])
                pc[0].append(ran_pokers[52])
                pc[0].append(ran_pokers[53])
                pc[0].sort()
                time.sleep(2)
            else:
                if sc2 == 0 or sc2 <= sc1:
                    print("电脑 2 不叫。")
                else:
                    print("电脑 2 叫了", sc2, "分。")
                    d = 1
                if sc2 == 3:
                    print("电脑 2 成为了地主。")
                    pc[1].append(ran_pokers[51])
                    pc[1].append(ran_pokers[52])
                    pc[1].append(ran_pokers[53])
                    pc[1].sort()
                    time.sleep(2)
                else:
                    time.sleep(0.2)
                    while True:
                        try:
                            sp = int(input("您要叫（分数）："))
                            if sp < 0 or sp > 3:
                                raise ValueError
                            break
                        except ValueError:
                            print("请输入 {x ∈ N+ | x ≤ 3} 范围内的数字。")
                        except KeyboardInterrupt:
                            print("按错键了，请重叫。")
                    if sp > max(sc2, sc1):
                        d = 2
                    if sp == 3:
                        pc[2].append(ran_pokers[51])
                        pc[2].append(ran_pokers[52])
                        pc[2].append(ran_pokers[53])
                        pc[2].sort()
                        print("您成为了地主。")
                        time.sleep(2)
                        time.sleep(0.2)
                    else:
                        time.sleep(0.2)
                        if d == -1:
                            print("无人叫地主，重发牌。")
                            continue
                        elif d == 0:
                            print("电脑 1 成为了地主。")
                            pc[0].append(ran_pokers[51])
                            pc[0].append(ran_pokers[52])
                            pc[0].append(ran_pokers[53])
                            pc[0].sort()
                        elif d == 1:
                            print("电脑 2 成为了地主。")
                            pc[1].append(ran_pokers[51])
                            pc[1].append(ran_pokers[52])
                            pc[1].append(ran_pokers[53])
                            pc[1].sort()
                        else:
                            print("您成为了地主。")
                            pc[2].append(ran_pokers[51])
                            pc[2].append(ran_pokers[52])
            break
        else:
            if sc2 == 0:
                print("电脑 2 不叫。")
            else:
                print("电脑 2 叫了", sc2, "分。")
                d = 1
            if sc2 == 3:
                print("电脑 2 成为了地主。")
                pc[1].append(ran_pokers[51])
                pc[1].append(ran_pokers[52])
                pc[1].append(ran_pokers[53])
                pc[1].sort()
                time.sleep(2)
            else:
                time.sleep(0.2)
                while True:
                    try:
                        sp = int(input("您要叫（分数）："))
                        if sp < 0 or sp > 3:
                            raise ValueError
                        break
                    except ValueError:
                        print("请输入 {x ∈ N+ | x ≤ 3} 范围内的数字。")
                    except KeyboardInterrupt:
                        print("按错键了，请重叫。")
                if sp > sc2:
                    d = 2
                if sp == 3:
                    pc[2].append(ran_pokers[51])
                    pc[2].append(ran_pokers[52])
                    pc[2].append(ran_pokers[53])
                    pc[2].sort()
                    print("您成为了地主。")
                    time.sleep(2)
                else:
                    time.sleep(0.2)
                    if sc1 == 0 or sc1 <= max(sp, sc2):
                        print("电脑 1 不叫。")
                    else:
                        print("电脑 1 叫了", sc1, "分。")
                        d = 0
                    if sc1 == 3:
                        print("电脑 1 成为了地主。")
                        pc[0].append(ran_pokers[51])
                        pc[0].append(ran_pokers[52])
                        pc[0].append(ran_pokers[53])
                        pc[0].sort()
                        time.sleep(2)
                    else:
                        time.sleep(0.2)
                        if d == -1:
                            print("无人叫地主，重发牌。")
                            continue
                        elif d == 0:
                            print("电脑 1 成为了地主。")
                            pc[0].append(ran_pokers[51])
                            pc[0].append(ran_pokers[52])
                            pc[0].append(ran_pokers[53])
                            pc[0].sort()
                        elif d == 1:
                            print("电脑 2 成为了地主。")
                            pc[1].append(ran_pokers[51])
                            pc[1].append(ran_pokers[52])
                            pc[1].append(ran_pokers[53])
                            pc[1].sort()
                        else:
                            print("您成为了地主。")
                            pc[2].append(ran_pokers[51])
                            pc[2].append(ran_pokers[52])
                            pc[2].append(ran_pokers[53])
                            pc[2].sort()
                        time.sleep(2)
            break

    if sp == 3 or sc1 == 3 or sc2 == 3:
        bei *= 2
        print("倍数增加至 %d。" % bei)
        
    last = [d, None]
    print("底牌是")
    print(ran_pokers[51])
    time.sleep(0.2)
    print(ran_pokers[52])
    time.sleep(0.2)
    print(ran_pokers[53])
    time.sleep(2)

    sc = [0, 0, 0]
    j = [1, 1, 1]
    for k in range(3):
        for i in pc[k]:
            sc[k] += max(0, i.size() - 10)
    if d == 0:
        s = max(sc[1], sc[2])
        if s == 0:
            j[0] = 5
        else:
            j[0] = min(5, sc[0] // s + 1)
        if sc[0] == 1:
            print("电脑 1 不加倍。")
        else:
            print("电脑 1 加了 %d 倍。" % j[0])
        if sc[0] == 0:
            j[1] = 5
        else:
            j[1] = min(5, sc[1] // sc[0] + 1)
        if j[1] == 1:
            print("电脑 2 不加倍。")
        else:
            print("电脑 2 加了 %d 倍。" % j[1])
        while True:
            try:
                j[2] = int(input("您要加倍（倍数）："))
                if j[2] < 1 or j[2] > 5:
                    raise ValueError
                break
            except ValueError:
                print("请输入 {x ∈ N | x ≤ 5} 范围内的数字。")
            except KeyboardInterrupt:
                print("按错键了，请重加倍。")
    elif d == 1:
        s = max(sc[0], sc[2])
        if s == 0:
            j[1] = 5
        else:
            j[1] = min(5, sc[1] // s + 1)
        if j[1] == 1:
            print("电脑 2 不加倍。")
        else:
            print("电脑 2 加了 %d 倍。" % j[1])
        while True:
            try:
                j[2] = int(input("您要加倍（倍数）："))
                if j[2] < 1 or j[2] > 5:
                    raise ValueError
                break
            except ValueError:
                print("请输入 {x ∈ N | x ≤ 5} 范围内的数字。")
            except KeyboardInterrupt:
                print("按错键了，请重加倍。")
        if sc[1] == 0:
            j[0] = 5
        else:
            j[0] = min(5, sc[0] // sc[1] + 1)
        if j[0] == 1:
            print("电脑 1 不加倍。")
        else:
            print("电脑 1 加了 %d 倍。" % j[0])
    else:
        while True:
            try:
                j[2] = int(input("您要加倍（倍数）："))
                if j[2] < 1 or j[2] > 5:
                    raise ValueError
                break
            except ValueError:
                print("请输入 {x ∈ N | x ≤ 5} 范围内的数字。")
            except KeyboardInterrupt:
                print("按错键了，请重加倍。")
        if sc[2] == 0:
            j[0] = 5
        else:
            j[0] = min(5, sc[0] // sc[2] + 1)
        if j[0] == 1:
            print("电脑 1 不加倍。")
        else:
            print("电脑 1 加了 %d 倍。" % j[0])
        if sc[2] == 0:
            j[1] = 5
        else:
            j[1] = min(5, sc[1] // sc[2] + 1)
        if j[1] == 1:
            print("电脑 2 不加倍。")
        else:
            print("电脑 2 加了 %d 倍。" % j[1])
    bei *= j[0]
    bei *= j[1]
    bei *= j[2]
    print("倍数增加至 %d。" % bei)
    time.sleep(2)

    t = [[], []]
    for i in pc[0]:
        t[0].append(i.size())
    for i in pc[1]:
        t[1].append(i.size())
    cf[0] = chai(t[0])
    cf[1] = chai(t[1])
    for i in pc[2]:
        jipai[i.size()] -= 1
    
def main_loop():
    global cnt
    global score
    global bei
    global chun
    cnt += 1
    print("现在是第", cnt, "回合。")
    print("现在基数是", 10 - int((cnt - 1) ** 0.5), "。")
    time.sleep(0.5)
    for i in range(3):
        now = (d + i) % 3
        chupai(now)
        time.sleep(2)
        if len(pc[now]) == 0:
            if chun != 0:
                print(random.choice(["春天。", "春天！", "要的就是春天。", "要的就是春天！"]))
                bei *= 2
                print("倍数增加至 %d。" % bei)
            dsc = (10 - int((cnt - 1) ** 0.5)) * bei
            d0 = dsc * ((0 == now or d != now and 0 != d) * max(1, 2 * (d == 0))\
- (not (0 == now or d != now and 0 != d)) * max(1, 2 * (d == 0)))
            d1 = dsc * ((1 == now or d != now and 1 != d) * max(1, 2 * (d == 1))\
- (not (1 == now or d != now and 1 != d)) * max(1, 2 * (d == 1)))
            d2 = dsc * ((2 == now or d != now and 2 != d) * max(1, 2 * (d == 2))\
- (not (2 == now or d != now and 2 != d)) * max(1, 2 * (d == 2)))
            score[0] += d0
            score[1] += d1
            score[2] += d2
            score[0] = max(0, score[0])
            score[1] = max(0, score[1])
            score[2] = max(0, score[2])
            print("电脑 1 分数增加 %d。" % d0)
            print("电脑 1 总分数 %d。" % score[0])
            print("电脑 2 分数增加 %d。" % d1)
            print("电脑 2 总分数 %d。" % score[1])
            print("您分数增加 %d。" % d2)
            print("您总分数 %d。" % score[2])
            return True

def chupai(now):
    global pc
    global d
    global cf
    global last
    global bei
    global chun
    global jipai
    if last[0] == now:
        last[1] = None
    if now == 2:
        print("电脑现在的牌是")
        for j, i in enumerate(jipai):
            if i:
                print("%d 个 %s" % (i, PNAME[j]))
        print("您现在的牌是")
        for i in pc[2]:
            print(i)
        print("您要出什么牌？")
        ans = " "
        anses = []
        anss = []
        con = True
        while True:
            while True:
                try:
                    ans = input()
                    break
                except KeyboardInterrupt:
                    print("按错键了，请重出。")
            while ans != "":
                try:
                    ans = Poker(ans)
                except KeyError:
                    print("这张牌不存在，请重出。")
                    ans = input()
                    continue
                if not ans in pc[2]:
                    print("您没有这张牌，请重出。")
                    ans = input()
                    continue
                pc[2].remove(ans)
                anses.append(ans)
                anss.append(ans.size())
                ans = input()
            try:
                pf = tpok(anss)
                if last[1] != None and not last[1] < pf:
                    for i in anses:
                        pc[2].append(i)
                    pc[2].sort()
                    anss = []
                    anses = []
                    print("要不过上一手牌，请重出。")
                    continue
                if pf.c != 0:
                    bei *= 2
                    print("倍数增加至 %d。" % bei)
                shuo = []
                if last[1] != None:
                    if chun == 1:
                        chun = 2
                    if chun == 2 and d == 2:
                        chun = 0
                if pf.lians > 1:
                    if last[1] != None:
                        shuo += ["大你。", "晚上。", "压死。"]
                    t = ""
                    for i in range(pf.start, pf.start + pf.lians):
                        t += (PNAME[i] + " ") * pf.lian
                    t += "。"
                    shuo.append(t)
                    if pf.lian == 1:
                        shuo.append("顺子。")
                        if pf.start + pf.lian == 11:
                            shuo.append("通天顺。")
                            shuo.append("通天顺！")
                        if pf.start == 13:
                            shuo = ["王炸。", "王炸！", "火箭。", "火箭！"]
                    if pf.lian == 2:
                        shuo.append("连对。")
                    if pf.lian == 3:
                        shuo = []
                        if pf.fen == 0:
                            shuo.append("飞机。")
                            shuo.append("飞机！")
                        else:
                            shuo.append("飞机带翅膀。")
                            shuo.append("飞机带翅膀！")
                else:
                    if pf.fen == 0:
                        shuo.append("%d 个 %s。" % (pf.lian, PNAME[pf.start]))
                        if pf.lian == 1:
                            shuo.append(PNAME[pf.start] + "。")
                            if pf.start > 11:
                                shuo.append(PNAME[pf.start] + "！")
                            if pf.start == 0:
                                shuo.append("先打张 2，探探路。")
                        if pf.lian == 2:
                            shuo.append("对 " + PNAME[pf.start] + "。")
                            if pf.start > 11:
                                shuo.append("对 " + PNAME[pf.start] + "！")
                        if pf.lian == 4:
                            shuo = ["炸弹。", "炸弹！", PNAME[pf.start] + " 炸。",\
PNAME[pf.start] + " 炸！"]
                    else:
                        shuo.append("%d 个 %s 带 %d 张牌。" % (pf.lian,\
PNAME[pf.start], pf.fen * pf.fens))
                        if pf.lian == 3:
                            if pf.fen == 1:
                                shuo.append("三带一。")
                            else:
                                shuo.append("三带二。")
                        if pf.lian == 4:
                            if pf.fen == 1:
                                shuo.append("四带二。")
                            else:
                                shuo.append("四带四。")
                print(random.choice(shuo))
                last[0] = 2
                last[1] = pf
                if len(pc[2]) == 0:
                    print("您赢了！")
                    first_p = 2
                    if d == 2:
                        print("地主获胜！")
                    else:
                        print("农民获胜！")
                    print("电脑 1 剩余牌：")
                    for i in pc[0]:
                        print(i)
                    time.sleep(0.5)
                    print("电脑 2 剩余牌：")
                    for i in pc[1]:
                        print(i)
                    time.sleep(0.5)
                    return 0
                print("您还剩 %d 张牌。" % len(pc[2]))
                break
            except IndexError:
                if anses == [] and last[1] != None:
                    print(random.choice(["不要。", "要不起。", "过。"]))
                    break
                for i in anses:
                    pc[2].append(i)
                pc[2].sort()
                anss = []
                anses = []
                print("该牌型不合理，请重出。")
    elif now == 0:
        k = None
        if last[1] == None:
            for i in cf[0][0]:
                if k == None or i.c < k.c or i.c == k.c and i.lians *\
70 + max(0, 2 - i.lians) * max(1, i.lian - 1) * 15 - i.start > k.lians\
* 70 + max(0, 2 - k.lians) * max(1, k.lian - 1) * 15 - k.start:
                    k = i
        else:
            for i in cf[0][0]:
                if last[1] < i and (k == None or i.c < k.c or i.c == k.c and\
i.start < k.start):
                    k = i
        if k != None and not (d != 0 and last[0] != d and last[0] != 0 and (\
k.lians == 1 and k.start > 11 or k.c != 0)):
            print("电脑 1 出了：")
            i = k
            if i.c != 0:
                bei *= 2
                print("倍数增加至 %d。" % bei)
            for j in range(i.start, i.start + i.lians):
                zz = 0
                while pc[0][zz].size() != j:
                    zz += 1
                for k in range(zz, zz + i.lian):
                    print(pc[0][k])
                    jipai[pc[0][k].size()] -= 1
                del pc[0][zz : zz + i.lian]
            for j in range(i.start, i.start + i.fens):
                zz = 0
                while pc[0][zz].size() != cf[0][i.fen][0]:
                    zz += 1
                for k in range(zz, zz + i.fen):
                    print(pc[0][k])
                    jipai[pc[0][k].size()] -= 1
                del pc[0][zz : zz + i.fen]
                del cf[0][i.fen][0]
            shuo = []
            if last[1] != None:
                if chun == 1:
                    chun = 2
                if chun == 2 and d == 0:
                    chun = 0
            if i.lians > 1:
                if last[1] != None:
                    shuo += ["大你。", "晚上。", "压死。"]
                t = ""
                for j in range(i.start, i.start + i.lians):
                    t += (PNAME[j] + " ") * i.lian
                t += "。"
                shuo.append(t)
                if i.lian == 1:
                    shuo.append("顺子。")
                    if i.start + i.lian == 11:
                        shuo.append("通天顺。")
                        shuo.append("通天顺！")
                    if i.start == 13:
                        shuo = ["王炸。", "王炸！", "火箭。", "火箭！"]
                if i.lian == 2:
                    shuo.append("连对。")
                if i.lian == 3:
                    shuo = []
                    if i.fen == 0:
                        shuo.append("飞机。")
                        shuo.append("飞机！")
                    else:
                        shuo.append("飞机带翅膀。")
                        shuo.append("飞机带翅膀！")
            else:
                if i.fen == 0:
                    shuo.append("%d 个 %s。" % (i.lian, PNAME[i.start]))
                    if i.lian == 1:
                        shuo.append(PNAME[i.start] + "。")
                        if i.start > 11:
                            shuo.append(PNAME[i.start] + "！")
                        if i.start == 0:
                            shuo.append("先打张 2，探探路。")
                    if i.lian == 2:
                        shuo.append("对 " + PNAME[i.start] + "。")
                        if i.start > 11:
                            shuo.append("对 " + PNAME[i.start] + "！")
                    if i.lian == 4:
                        shuo = ["炸弹。", "炸弹！", PNAME[i.start] + " 炸。",\
PNAME[i.start] + " 炸！"]
                else:
                    shuo.append("%d 个 %s 带 %d 张牌。" % (i.lian,\
PNAME[i.start], i.fen * i.fens))
                    if i.lian == 3:
                        if i.fen == 1:
                            shuo.append("三带一。")
                        else:
                            shuo.append("三带二。")
                    if i.lian == 4:
                        if i.fen == 1:
                            shuo.append("四带二。")
                        else:
                            shuo.append("四带四。")
            print(random.choice(shuo))
            last[0] = 0
            last[1] = i
            cf[0][0].remove(i)
            if len(pc[0]) == 0:
                print("电脑 1 赢了！")
                first_p = 0
                if d == 0:
                    print("地主获胜！")
                else:
                    print("农民获胜！")
                print("电脑 2 剩余牌：")
                for i in pc[1]:
                    print(i)
                time.sleep(0.5)
                print("您剩余牌：")
                for i in pc[2]:
                    print(i)
                time.sleep(0.5)
                return 0
            print("电脑 1 还剩 %d 张牌。" % len(pc[0]))
        else:
            print(random.choice(["不要。", "要不起。", "过。"]))
    else:
        k = None
        if last[1] == None:
            for i in cf[1][0]:
                if k == None or i.c < k.c or i.c == k.c and i.lians *\
70 + max(0, 2 - i.lians) * max(1, i.lian - 1) * 15 - i.start > k.lians\
* 70 + max(0, 2 - k.lians) * max(1, k.lian - 1) * 15 - k.start:
                    k = i
        else:
            for i in cf[1][0]:
                if last[1] < i and (k == None or i.c < k.c or i.c == k.c and\
i.start < k.start):
                    k = i
        if k != None and not (d != 1 and last[0] != d and last[0] != 1 and (\
k.lians == 1 and k.start > 11 or k.c != 0)):
            print("电脑 2 出了：")
            i = k
            if i.c != 0:
                bei *= 2
                print("倍数增加至 %d。" % bei)
            for j in range(i.start, i.start + i.lians):
                zz = 0
                while pc[1][zz].size() != j:
                    zz += 1
                for k in range(zz, zz + i.lian):
                    print(pc[1][k])
                    jipai[pc[1][k].size()] -= 1
                del pc[1][zz : zz + i.lian]
            for j in range(i.start, i.start + i.fens):
                zz = 0
                while pc[1][zz].size() != cf[1][i.fen][0]:
                    zz += 1
                for k in range(zz, zz + i.fen):
                    print(pc[1][k])
                    jipai[pc[1][k].size()] -= 1
                del pc[1][zz : zz + i.fen]
                del cf[1][i.fen][0]
            shuo = []
            if last[1] != None:
                if chun == 1:
                    chun = 2
                if chun == 2 and d == 1:
                    chun = 0
            if i.lians > 1:
                if last[1] != None:
                    shuo += ["大你。", "晚上。", "压死。"]
                t = ""
                for j in range(i.start, i.start + i.lians):
                    t += (PNAME[j] + " ") * i.lian
                t += "。"
                shuo.append(t)
                if i.lian == 1:
                    shuo.append("顺子。")
                    if i.start + i.lian == 11:
                        shuo.append("通天顺。")
                        shuo.append("通天顺！")
                    if i.start == 13:
                        shuo = ["王炸。", "王炸！", "火箭。", "火箭！"]
                if i.lian == 2:
                    shuo.append("连对。")
                if i.lian == 3:
                    shuo = []
                    if i.fen == 0:
                        shuo.append("飞机。")
                        shuo.append("飞机！")
                    else:
                        shuo.append("飞机带翅膀。")
                        shuo.append("飞机带翅膀！")
            else:
                if i.fen == 0:
                    shuo.append("%d 个 %s。" % (i.lian, PNAME[i.start]))
                    if i.lian == 1:
                        shuo.append(PNAME[i.start] + "。")
                        if i.start > 11:
                            shuo.append(PNAME[i.start] + "！")
                        if i.start == 0:
                            shuo.append("先打张 2，探探路。")
                    if i.lian == 2:
                        shuo.append("对 " + PNAME[i.start] + "。")
                        if i.start > 11:
                            shuo.append("对 " + PNAME[i.start] + "！")
                    if i.lian == 4:
                        shuo = ["炸弹。", "炸弹！", PNAME[i.start] + " 炸。",\
PNAME[i.start] + " 炸！"]
                else:
                    shuo.append("%d 个 %s 带 %d 张牌。" % (i.lian,\
PNAME[i.start], i.fen * i.fens))
                    if i.lian == 3:
                        if i.fen == 1:
                            shuo.append("三带一。")
                        else:
                            shuo.append("三带二。")
                    if i.lian == 4:
                        if i.fen == 1:
                            shuo.append("四带二。")
                        else:
                            shuo.append("四带四。")
            print(random.choice(shuo))
            last[0] = 1
            last[1] = i
            cf[1][0].remove(i)
            if len(pc[1]) == 0:
                print("电脑 2 赢了！")
                first_p = 1
                if d == 1:
                    print("地主获胜！")
                else:
                    print("农民获胜！")
                print("电脑 1 剩余牌：")
                for i in pc[0]:
                    print(i)
                time.sleep(0.5)
                print("您剩余牌：")
                for i in pc[2]:
                    print(i)
                time.sleep(0.5)
                return 0
            print("电脑 2 还剩 %d 张牌。" % len(pc[1]))
        else:
            print(random.choice(["不要。", "要不起。", "过。"]))
