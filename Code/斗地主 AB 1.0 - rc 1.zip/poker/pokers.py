from cstart import *

class Poker():
    def __init__(self, a):
        """Init pokers."""
        if(type(a) == type(1)):
            self.value = a
            self.pok = POKERR[a - 1]
        elif(type(a) == type("1")):
             self.pok = a
             self.value = POKER[a]
        else:
            raise TypeError("%s object is not int or str" % str(type(1))[6 : len(
                str(type(1))) - 1])
    def __lt__(self, other):
        """Cmp pokers."""
        if self.value < other.value:
            return True
        else:
            return False
    def __eq__(self, other):
        """Cmp pokers."""
        if self.value == other.value:
            return True
        else:
            return False
    def __str__(self):
        """Turn self's type to str."""
        return self.pok
    def __int__(self):
        """Turn self's type to int."""
        return self.value
    def size(self):
        """Size of pokers."""
        return PSIZE[self.value]

class PokFunc():
    def __init__(self, lian, lians, fen, fens, start):
        """Init pok funcs."""
        if fen > 2 or lian == 0:
            raise IndexError("Lian, lians, fen, fens, start or end index out o\
f range")
        for j, i in enumerate(PFM[lian]):
            if type(i["lians"]) == type(1):
                if lians < i["lians"]:
                    continue
            else:
                if lians != eval(i["lians"]):
                    continue
            if type(i["fens"]) == type(1):
                if fens > i["fens"]:
                    continue
            else:
                if fens != eval(i["fens"]):
                    continue
            if start < i["mn"]:
                continue
            if start + lians  - 1 > i["mx"]:
                continue
            self.c = 0
            break
        else:
            if PBM[lian] == None:
                raise IndexError("Lian, lians, fen, fens, start or end index o\
ut of range")
            for j, i in enumerate(PBM[lian]):
                if type(i["lians"]) == type(1):
                    if lians < i["lians"]:
                        continue
                else:
                    if lians != eval(i["lians"]):
                        continue
                if type(i["fens"]) == type(1):
                    if fens < i["fens"]:
                        continue
                else:
                    if fens != eval(i["fens"]):
                        continue
                if start < i["mn"]:
                    continue
                if start + lians - 1 > i["mx"]:
                    continue
                if lians == 2:
                    self.c = 2
                else:
                    self.c = 1
                break
            else:
                raise IndexError("Lian, lians, fen, fens, start or end index o\
ut of range")
        self.lian = lian
        self.lians = lians
        self.fen = fen
        self.fens = fens
        self.start = start
    def __lt__(self, other):
        """Cmp poker funcs."""
        if self.c < other.c:
            return True
        if self.c > other.c:
            return False
        if self.lian == other.lian and self.lians == other.lians and self.fen\
== other.fen and self.fens == other.fens and self.start < other.start:
            return True
        else:
            return False
